#!/bin/bash
set -e
cd /var/ictf/services/noradioactive
/sbin/start-stop-daemon -b --start --chdir /var/ictf/services/noradioactive --exec /usr/bin/python -- /ictf/services/noradioactive/noradioactive.pyo
        
