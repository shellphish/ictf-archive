#!/bin/bash
pkill -u uranus
sleep 2
pkill -KILL -u uranus
