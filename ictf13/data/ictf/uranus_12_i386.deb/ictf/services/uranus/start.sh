#!/bin/bash
set -e
cd /var/ictf/services/uranus

NODEJS=/usr/bin/node
if [ -x /usr/bin/nodejs ]; then
    NODEJS=/usr/bin/nodejs
fi

/sbin/start-stop-daemon -b --start --chdir /var/ictf/services/uranus --exec $NODEJS -- /ictf/services/uranus/server.js
