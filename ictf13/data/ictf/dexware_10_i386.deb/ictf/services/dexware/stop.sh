#!/bin/bash
pkill -u dexware
sleep 1
pkill -KILL -u dexware
