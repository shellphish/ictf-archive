#!/bin/bash

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd $DIR

MAINJAR=$DIR/data/dexware.jar

TMPDIR=/tmp/dexware
rm -rf $TMPDIR/*
mkdir -p $TMPDIR
chmod go-rwx $TMPDIR

/sbin/start-stop-daemon -b --start --chdir $DIR --exec $DIR/dalvik/dalvik -- -cp $MAINJAR DexWare
