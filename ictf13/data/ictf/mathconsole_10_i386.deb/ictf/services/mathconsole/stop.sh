#!/bin/bash
pkill -u mathconsole
sleep 1
pkill -KILL -u mathconsole
