#!/bin/bash
set -e
cd /var/ictf/services/mathconsole
/sbin/start-stop-daemon -b --start --chdir /var/ictf/services/mathconsole --name game_server.pyc --exec /usr/bin/python -- /ictf/services/mathconsole/game_server.pyc
