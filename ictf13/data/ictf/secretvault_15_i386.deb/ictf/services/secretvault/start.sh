#!/bin/bash
set -e
cd /var/ictf/services/secretvault
/sbin/start-stop-daemon -b --chdir /var/ictf/services/secretvault --start --exec /ictf/services/secretvault/secretvault -- 2190
