#!/bin/bash
pkill -u secretvault
sleep 1
pkill -KILL -u secretvault
        
