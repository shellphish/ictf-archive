#!/bin/sh
export HOME=/opt/prison
cd /opt/prison
exec script -q -c 'rbash -i' /dev/null
