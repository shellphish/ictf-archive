enable -n exec

[ -z "$PS1" ] && return

echo "========================= JAIL ============================="
echo "Despite your best effort, they got you... Now you're rotting away in this smelly prison, nothing more intelligent than the flies to keep you company. But you've got a plan! Your co-conspirators and you are planning to bust you through a tunnel you're digging from your bathroom! Gotta dig it first, though..."
echo ""

export PATH=$HOME/bin
