. .bashrc
