#!/bin/sh
/sbin/start-stop-daemon \
    --stop \
    --pidfile /var/ctf/bassretard//running.pid
