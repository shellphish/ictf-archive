#!/bin/sh
/sbin/start-stop-daemon \
    --stop \
    --pidfile /var/ctf/water//running.pid
