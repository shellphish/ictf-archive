# Microsoft Developer Studio Project File - Name="TCPDump" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 6.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Console Application" 0x0103

CFG=TCPDump - Win32 Debug
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE use the Export Makefile command and run
!MESSAGE 
!MESSAGE NMAKE /f "TCPDump.mak".
!MESSAGE 
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "TCPDump.mak" CFG="TCPDump - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "TCPDump - Win32 Release" (based on "Win32 (x86) Console Application")
!MESSAGE "TCPDump - Win32 Debug" (based on "Win32 (x86) Console Application")
!MESSAGE 

# Begin Project
# PROP AllowPerConfigDependencies 1
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
CPP=cl.exe
RSC=rc.exe

!IF  "$(CFG)" == "TCPDump - Win32 Release"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "../../"
# PROP Intermediate_Dir "Release"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_CONSOLE" /D "_MBCS" /YX /FD /c
# ADD CPP /nologo /W3 /GX /O2 /I "../../../winpcap/wpcap/libpcap/bpf" /I "../../../winpcap/wpcap/libpcap" /I "../../../winpcap/wpcap/libpcap/Win32/Include" /I "../../../winpcap/wpcap/libpcap/Win32/Include/net" /I "../../Win32/Include" /I "../../linux-Include" /I "../../lbl" /I "../../../winpcap/wpcap/libpcap/Win32/Include/ipv6kit" /D "_CONSOLE" /D "NDEBUG" /D "__STDC__" /D "INET6" /D "WIN32" /D "_MBCS" /D SIZEOF_CHAR=1 /D SIZEOF_SHORT=2 /D SIZEOF_INT=4 /D HAVE_ADDRINFO=1 /YX /FD /c
# ADD BASE RSC /l 0x410 /d "NDEBUG"
# ADD RSC /l 0x410 /d "NDEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /machine:I386
# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib wsock32.lib /nologo /subsystem:console /machine:I386 /out:"release/WinDump.exe"

!ELSEIF  "$(CFG)" == "TCPDump - Win32 Debug"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "TCPDump_"
# PROP BASE Intermediate_Dir "TCPDump_"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "../../"
# PROP Intermediate_Dir "Debug"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /Gm /GX /Zi /Od /D "WIN32" /D "_DEBUG" /D "_CONSOLE" /D "_MBCS" /YX /FD /c
# ADD CPP /nologo /W3 /Gm /Gi /GX /ZI /I "../../../winpcap/wpcap/libpcap/bpf" /I "../../../winpcap/wpcap/libpcap" /I "../../../winpcap/wpcap/libpcap/Win32/Include" /I "../../../winpcap/wpcap/libpcap/Win32/Include/net" /I "../../Win32/Include" /I "../../linux-Include" /I "../../lbl" /I "../../../winpcap/wpcap/libpcap/Win32/Include/ipv6kit" /D "_CONSOLE" /D "_DEBUG" /D "__STDC__" /D "INET6" /D "WIN32" /D "_WINDOWS" /D "_MBCS" /D SIZEOF_CHAR=1 /D SIZEOF_SHORT=2 /D SIZEOF_INT=4 /D "HAVE_ADDRINFO" /FR /YX /FD /c
# ADD BASE RSC /l 0x410 /d "_DEBUG"
# ADD RSC /l 0x410 /d "_DEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /debug /machine:I386 /pdbtype:sept
# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib wsock32.lib /nologo /subsystem:console /map /debug /debugtype:both /machine:I386 /out:"debug/WinDump.exe" /pdbtype:sept
# SUBTRACT LINK32 /pdb:none

!ENDIF 

# Begin Target

# Name "TCPDump - Win32 Release"
# Name "TCPDump - Win32 Debug"
# Begin Source File

SOURCE=..\..\acconfig.h
# End Source File
# Begin Source File

SOURCE=..\..\missing\addrinfo.h
# End Source File
# Begin Source File

SOURCE=..\..\missing\addrsize.h
# End Source File
# Begin Source File

SOURCE=..\..\addrtoname.c
# End Source File
# Begin Source File

SOURCE=..\..\addrtoname.h
# End Source File
# Begin Source File

SOURCE=..\..\appletalk.h
# End Source File
# Begin Source File

SOURCE=..\..\missing\bittypes.h
# End Source File
# Begin Source File

SOURCE=..\..\bootp.h
# End Source File
# Begin Source File

SOURCE=..\..\bpf_dump.c
# End Source File
# Begin Source File

SOURCE=..\..\missing\cdecl_ext.h
# End Source File
# Begin Source File

SOURCE=..\..\decnet.h
# End Source File
# Begin Source File

SOURCE=..\..\dhcp6.h
# End Source File
# Begin Source File

SOURCE=..\..\dhcp6opt.h
# End Source File
# Begin Source File

SOURCE=..\..\ethertype.h
# End Source File
# Begin Source File

SOURCE=..\..\extract.h
# End Source File
# Begin Source File

SOURCE=..\..\fddi.h
# End Source File
# Begin Source File

SOURCE=..\..\gmt2local.c
# End Source File
# Begin Source File

SOURCE=..\..\gmt2local.h
# End Source File
# Begin Source File

SOURCE=..\..\lbl\gnuc.h
# End Source File
# Begin Source File

SOURCE="..\..\Win32-Include\net\if.h"
# End Source File
# Begin Source File

SOURCE="..\..\Win32-Include\net\if_arp.h"
# End Source File
# Begin Source File

SOURCE="..\..\Win32-Include\netinet\if_ether.h"
# End Source File
# Begin Source File

SOURCE=..\..\igrp.h
# End Source File
# Begin Source File

SOURCE="..\..\Win32-Include\netinet\in_systm.h"
# End Source File
# Begin Source File

SOURCE=..\..\missing\inet_aton.c
# End Source File
# Begin Source File

SOURCE=..\..\missing\inet_ntop.c
# End Source File
# Begin Source File

SOURCE=..\..\missing\inet_pton.c
# End Source File
# Begin Source File

SOURCE="..\..\Win32-include\inetprivate.h"
# End Source File
# Begin Source File

SOURCE=..\..\interface.h
# End Source File
# Begin Source File

SOURCE="..\..\Win32-Include\netinet\ip.h"
# End Source File
# Begin Source File

SOURCE="..\..\Win32-Include\netinet\ip_icmp.h"
# End Source File
# Begin Source File

SOURCE="..\..\Win32-Include\netinet\ip_var.h"
# End Source File
# Begin Source File

SOURCE=..\..\ipsec_doi.h
# End Source File
# Begin Source File

SOURCE=..\..\ipx.h
# End Source File
# Begin Source File

SOURCE=..\..\isakmp.h
# End Source File
# Begin Source File

SOURCE=..\..\l2tp.h
# End Source File
# Begin Source File

SOURCE=..\..\lane.h
# End Source File
# Begin Source File

SOURCE=..\..\llc.h
# End Source File
# Begin Source File

SOURCE=..\..\machdep.c
# End Source File
# Begin Source File

SOURCE=..\..\machdep.h
# End Source File
# Begin Source File

SOURCE=..\..\mib.h
# End Source File
# Begin Source File

SOURCE="..\..\Win32-Include\arpa\nameser.h"
# End Source File
# Begin Source File

SOURCE=..\..\netbios.h
# End Source File
# Begin Source File

SOURCE="..\..\Win32-Include\net\netdb.h"
# End Source File
# Begin Source File

SOURCE=..\..\nfs.h
# End Source File
# Begin Source File

SOURCE=..\..\nfsfh.h
# End Source File
# Begin Source File

SOURCE=..\..\nfsv2.h
# End Source File
# Begin Source File

SOURCE=..\..\ntp.h
# End Source File
# Begin Source File

SOURCE=..\..\oakley.h
# End Source File
# Begin Source File

SOURCE=..\..\ospf.h
# End Source File
# Begin Source File

SOURCE=..\..\ospf6.h
# End Source File
# Begin Source File

SOURCE=..\..\parsenfsfh.c
# End Source File
# Begin Source File

SOURCE="..\..\Win32-Include\net\paths.h"
# End Source File
# Begin Source File

SOURCE=..\..\ppp.h
# End Source File
# Begin Source File

SOURCE="..\..\print-ah.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-arp.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-ascii.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-atalk.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-atm.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-bgp.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-bootp.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-bxxp.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-cdp.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-chdlc.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-cip.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-cnfp.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-decnet.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-dhcp6.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-domain.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-dvmrp.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-egp.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-esp.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-ether.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-fddi.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-frag6.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-gre.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-icmp.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-icmp6.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-igmp.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-igrp.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-ip.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-ip6.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-ip6opts.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-ipcomp.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-ipx.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-isakmp.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-isoclns.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-krb.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-l2tp.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-lane.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-lcp.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-llc.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-mobile.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-netbios.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-nfs.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-ntp.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-null.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-ospf.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-ospf6.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-pim.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-ppp.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-pppoe.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-radius.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-raw.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-rip.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-ripng.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-rt6.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-rx.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-sl.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-sll.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-smb.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-snmp.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-stp.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-sunrpc.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-tcp.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-telnet.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-tftp.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-timed.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-token.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-udp.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-vjc.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-vrrp.c"
# End Source File
# Begin Source File

SOURCE="..\..\print-wb.c"
# End Source File
# Begin Source File

SOURCE=..\..\missing\resolv6.h
# End Source File
# Begin Source File

SOURCE=..\..\missing\resolv_ext.h
# End Source File
# Begin Source File

SOURCE=..\..\route6d.h
# End Source File
# Begin Source File

SOURCE="..\..\Win32-Include\rpc\rpc_cut.h"
# End Source File
# Begin Source File

SOURCE=..\..\rx.h
# End Source File
# Begin Source File

SOURCE=..\..\savefile.h
# End Source File
# Begin Source File

SOURCE=..\..\savestr.c
# End Source File
# Begin Source File

SOURCE=..\..\savestr.h
# End Source File
# Begin Source File

SOURCE=..\..\setsignal.c
# End Source File
# Begin Source File

SOURCE=..\..\setsignal.h
# End Source File
# Begin Source File

SOURCE=..\..\smb.h
# End Source File
# Begin Source File

SOURCE=..\..\smbutil.c
# End Source File
# Begin Source File

SOURCE=..\..\missing\sockstorage.h
# End Source File
# Begin Source File

SOURCE=..\..\strcasecmp.c
# End Source File
# Begin Source File

SOURCE=..\..\missing\strlcat.c
# End Source File
# Begin Source File

SOURCE=..\..\missing\strlcpy.c
# End Source File
# Begin Source File

SOURCE="..\..\Win32-Include\netinet\tcp.h"
# End Source File
# Begin Source File

SOURCE="..\..\Win32-Include\netinet\tcp_var.h"
# End Source File
# Begin Source File

SOURCE=..\..\Tcpdump.c
# End Source File
# Begin Source File

SOURCE="..\..\Win32-Include\netinet\tcpip.h"
# End Source File
# Begin Source File

SOURCE="..\..\Win32-Include\arpa\tftp.h"
# End Source File
# Begin Source File

SOURCE="..\..\Win32-Include\netinet\udp.h"
# End Source File
# Begin Source File

SOURCE="..\..\Win32-Include\netinet\udp_var.h"
# End Source File
# Begin Source File

SOURCE="..\..\Win32-Include\unistd.h"
# End Source File
# Begin Source File

SOURCE=..\..\util.c
# End Source File
# Begin Source File

SOURCE="..\..\Win32\Src\w32_fzs.c"
# End Source File
# Begin Source File

SOURCE="..\..\Win32-Include\w32_fzs.h"
# End Source File
# Begin Source File

SOURCE=..\..\..\winpcap\wpcap\lib\wpcap.lib
# End Source File
# End Target
# End Project
